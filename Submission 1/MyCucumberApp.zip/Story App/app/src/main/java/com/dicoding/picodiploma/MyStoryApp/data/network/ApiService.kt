package com.dicoding.picodiploma.MyStoryApp.data.network

import com.dicoding.picodiploma.MyStoryApp.data.response.AddNewStoryResponse
import com.dicoding.picodiploma.MyStoryApp.data.response.DetailStoryResponse
import com.dicoding.picodiploma.MyStoryApp.data.response.StoryResponse
import com.dicoding.picodiploma.MyStoryApp.data.response.LoginResponse
import com.dicoding.picodiploma.MyStoryApp.data.response.RegisterResponse
import okhttp3.Call
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*

interface ApiService {
    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): RegisterResponse

    @FormUrlEncoded
    @POST("login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): LoginResponse

    @GET("stories")
    suspend fun getStories(): StoryResponse

    @Multipart
    @POST("stories")
    suspend fun upStory(
        @Part file: MultipartBody.Part,
        @Part("description") description: RequestBody,
    ): AddNewStoryResponse

    @GET("stories/{id}")
    suspend fun getStory(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ): DetailStoryResponse
}